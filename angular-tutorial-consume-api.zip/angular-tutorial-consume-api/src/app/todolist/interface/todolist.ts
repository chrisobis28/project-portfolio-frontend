export interface Todolist {
    projectId?: string;
    description: string;
}