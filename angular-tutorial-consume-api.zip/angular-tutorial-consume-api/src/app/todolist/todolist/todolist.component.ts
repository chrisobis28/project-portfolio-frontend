import { AsyncPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Todolist } from '../interface/todolist';
import { TodolistService } from '../service/todolist.service';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.scss']
})
export class TodolistComponent implements OnInit {
  
  constructor(private readonly todolistService: TodolistService) {}

  ngOnInit(): void {
      this.todolistService.getAllTodolist().subscribe((response: Todolist[]) => {
        console.log(response, 'res');
      })
    }

 }